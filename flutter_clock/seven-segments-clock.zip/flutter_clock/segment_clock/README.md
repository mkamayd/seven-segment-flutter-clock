# segment_clock

A seven segment clock that on special hours it change the colors.



